import csv
import io
import os
import re
import shlex
import subprocess
import sys
from xml.etree import ElementTree as ET

class NmapCommandParser(object):
    """
    Object for parsing the xml results
    
    Each function below will correspond to the parse
    for each nmap command or option.
    """
    def __init__(self, xml_et):
        self.xml_et = xml_et#element
        self.xml_root = None
        self.port_result_array=[]
            
    def filter_top_ports(self, xmlroot):
        """
        Given the xmlroot return the all the ports that are open from
        that tree
        """
        try:
            #port_result_dict = {}
            #port_result_array=[]

            
            scanned_host = xmlroot.findall("host") #scanned_host= <host>...</host>所有的值，找每個ip的掃瞄結果
            stats = xmlroot.attrib  #attributes of the root element(XML裡面 nmaprun 那行)
            
            for hosts in scanned_host:
                port_result_dict = {}
                address = hosts.find("address").get("addr")
                port_result_dict["ip"]=address # A little trick to avoid errors         
                if (hosts.find("os/osmatch")): #delete the None
                    port_result_dict["os"]=self.parse_os(hosts)
                if (hosts.find("ports/port")):
                    port_result_dict["ports"] = self.parse_ports(hosts)
                self.port_result_array.append(port_result_dict)

        except Exception as e:
            raise(e)
        finally:
            return self.port_result_array
   
    
    def parse_os(self, os_results):
        """
        parses os results
        """
        
        #os = os_results.find("")
        os_list = []
        if os is not None:
            for match in os_results.findall("os/osmatch"):
                os_list.append(match.find("osclass").find("cpe").text)
            return os_list
        else:
            return {}
    def parse_ports(self, xml_hosts):
        """
        Parse parts from xml
        """
        open_ports_list = []
             
        for port in xml_hosts.findall("ports/port"): #find <port> element inside the <ports> element in the xml_hosts object
            open_ports = {}
            if ((port.find("state").attrib["state"]) == "open"):
                if ((port.attrib['protocol']) == "tcp"):
                    open_ports["port"]=port.attrib['portid']+"/"+port.attrib['protocol']
                
            if(port.find('state') is not None):
                if ((port.find("state").attrib["state"]) == "open"):
                    open_ports["state"]=port.find("state").attrib["state"]
           
            if(port.find('service') is not None ):
                if ((port.find("state").attrib["state"]) == "open"):
                    open_ports["service"]=port.find("service").attrib["name"]
            if(port.find('service') is not None):
                for cp in port.find("service").findall("cpe"):
                    open_ports["cpe"] =cp.text
            

            
            if( "product" in port.find("service").attrib ):
                open_ports["product"]=port.find("service").attrib["product"]

            if("version" in port.find("service").attrib ):
                open_ports["version"]=port.find("service").attrib["version"]
                
            
            if(port.findall("script")):
                id = port.find("script").attrib["id"]
                output = [ i.strip() for i in (port.find("script").attrib["output"].lstrip("\n").rstrip("\n").split("\n"))]
                open_ports["script"]= {"id": id, "output": output}

            if open_ports :
                open_ports_list.append(open_ports)
        v_list = []
        for script in xml_hosts.findall("hostscript/script"):
            s = script.attrib["id"]
            match = re.search(r"(.*vuln-)(.*)", s)
            v_list.append(match[2])
        open_vs = {}
        open_vs["sp-vulunbility"] = v_list
        open_ports_list.append(open_vs)
            
        return open_ports_list
                    