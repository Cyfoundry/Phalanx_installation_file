# from distutils.core import setup
# from setuptools import find_packages
from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent

setup(name='cusnmap',
      version='0.1.4',
      packages=find_packages(),
      include_package_data=True,
      package_data={'data': []},
      description='Hook Nmap to Scan',
      long_description='',
      author='jimchang,nilo',
      author_email='jimchang@cyfoundry.com,nilo@cyfoundry.com',
      url='https://cyfoundry.local.com',
      license='MIT',
      install_requires=['simplejson==3.18.4', 'asyncio'],
      entry_points={
          'console_scripts': [
              'cusnmap=cusnmap.main:main',
          ],
      },
)
